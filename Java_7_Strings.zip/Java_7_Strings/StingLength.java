package Java_7_Strings;

public class StingLength {
	public static void main(String[] args) {
		String txt = "HGDFTTRJKHGJKLJHGFNMBVNGFGHJKHGFHJKHG";
		System.out.println("The length of the given string is:" + txt.length()); /*A String in Java is actually an object, which contain methods
		                                                                           that can perform certain operations on strings.
		                                                                          For example, the length of a string can be found with the length() 
		                                                                          method:*/
	}
}
