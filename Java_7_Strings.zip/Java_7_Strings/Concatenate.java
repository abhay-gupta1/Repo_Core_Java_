package Java_7_Strings;

public class Concatenate {
	public static void main(String[] args) {
		String firstName = "Abhay";
		String lastName = "Gupta";
		System.out.println(firstName +" "+ lastName); // concatenate two strings
		
		String fName = "Aditi";
		String lastName1 = "Malik";
		System.out.println(fName.concat(" "+ lastName)); // using concat method
	}
}
