package Java_7_Strings;

public class FirstString {
	public static void main(String[] args) {
		String greeting = "Hello Abhay!"; /* Strings are used for storing text. 
		                                     A String variable contains a collection of characters surrounded by double quotes:*/
		System.out.println(greeting);
				
	}
}
