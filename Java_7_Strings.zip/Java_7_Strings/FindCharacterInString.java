package Java_7_Strings;

public class FindCharacterInString {
	public static void main(String[] args) {
		String str = "There should be some changes required to solve";
		System.out.println(str.indexOf("be")); /*The indexOf() method returns the index (the position) of the
		                                        first occurrence of a specified text in a string (including whitespace):*/
	}
}
